/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estruturasderepeticao;

import java.util.Scanner;

/**
 *
 * @author Gabriel Margarido
 */
/*
    Exercitando as estruturas de repeticao
    com o exercicio de digitar N cambalhotas
    e o metodo ser executado N vezes.
*/
public class EstruturasDeRepeticao {

    /**
     * @param indice
     */
    public static void darCambalhota(int indice) {
        int numeroC = 0;
        while(numeroC<indice){
            numeroC = numeroC + 1;
            System.out.println("N."+ numeroC +" Dei cambalhota!");
        }
        
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);      
        while(true){
            System.out.println("Quantas cambalhotas? (int)");
            
            //Entrada de dados do usuario
            int cambalhota;
            cambalhota = entrada.nextInt();
            
            //Executa metodo
            darCambalhota(cambalhota);
        }
    }
    
}
