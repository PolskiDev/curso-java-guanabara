/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package estruturafor;

/**
 *
 * @author Gabriel Margarido
 */
public class EstruturaFOR {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        for(int i=0;i<4; i++) {
            //ESTRUTURA BASICA;
            //System.out.println("N."+i+" Pulei cambalhota");
            
            //ESTRUTURA MAIS COMPLETA;
            System.out.println("N."+ (i+1) +" Pulei cambalhota");
        }
        
        /*  ***ESTRUTURA LOGICA DO *FOR* ***
            for(variavelDeControle, condicao, some mais um) {
                //acao a ser executada;
            }
        
            Enquanto "i" for menor que 4 entao, some mais um {
                execute esta intrucao;
            }
        
            ***OBSERVACAO LOGICA:***
            Em java FOR e WHILE sao no fundo a mesma coisa,
            porem FOR eh um WHILE bem simplificado e automatizado,
            importante aprender e dominar esta estrutura de repeticao.
        
            ***CONVENCAO LOGICA***
            Normalmente usamos letras como [i, j , k, n OU m] para
            o nome da variavel de controle, mas nada impede que
            usemos outras letras ou ate mesmo nomes em variaveis de
            controle.
            
            ***NOMENCLATURAS DAS ESTRUTURAS***
            A estrutura de repeticao FOR eh chamada de
            "Estrutura de repeticao com variavel de controle."
            Sendo neste caso a variavel "i" como variavel de
            controle.
        */
    }
    
}
