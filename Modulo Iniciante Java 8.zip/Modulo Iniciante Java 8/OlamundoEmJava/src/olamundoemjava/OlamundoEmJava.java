/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package olamundoemjava;

import java.util.Scanner;

/**
 * @author Gabriel Margarido
 */
public class OlamundoEmJava {
    
    public static void soma(int a, int b) {
        int resultado = a + b;
        System.out.println("A soma de "+a+" com "+b+" eh: " +resultado);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner aluno = new Scanner(System.in);
        Scanner notaDoAluno = new Scanner(System.in);
        
        //Cria um loop de repeticao com WHILE TRUE;
        while(true){
            System.out.print("Digite um nome: ");
            String nome = aluno.nextLine(); //Declara a variavel "nome";

            System.out.print("Digite a nota do aluno: ");
            float nota = notaDoAluno.nextFloat(); //Declara a variavel "nota";
            
            //Compara o nivel da nota do aluno;
            if(nota>8){
                System.out.println("Que nota boa!");
            }else{
                //Segundo bloco caso o primeiro seja falso;
                if(nota>4&&nota<=8) {
                    System.out.println("Bem mais ou menos");
                }if(nota<=2){
                    System.out.println("Suas notas estao muito baixas!");
                }else{
                    System.out.println("Vai estudar malandro!");
                }

            }
            //Imprime a soma de 5 e 7;
            soma(5,7);
        }
    }
    /*fim do programa*/
    //return 0;
}
