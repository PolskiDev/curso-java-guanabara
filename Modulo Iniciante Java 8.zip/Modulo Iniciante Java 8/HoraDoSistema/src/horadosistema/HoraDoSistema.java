/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package horadosistema;

import java.util.Date;

/** @author Gabriel Margarido*/

public class HoraDoSistema {
    public static void main(String[] args) {
        // TODO code application logic here
        
        Date relogio = new Date(); //Cria o objeto "relogio";
        
        /*Imprime na tela a hora atual do sistema
        (convertendo os dados do nosso objeto "relogio" para string)*/
        System.out.println("A hora do sistema eh: "+relogio.toString());
        
        /*Fim do programa*/
        //return 0;
    }
    
}
