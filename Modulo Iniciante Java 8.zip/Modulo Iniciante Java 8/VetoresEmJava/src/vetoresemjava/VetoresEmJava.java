/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vetoresemjava;

/**
 *
 * @author Gabriel Margarido
 */
public class VetoresEmJava {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*              O QUE EH UM VETOR?
            Todo vetor eh uma variavel que pode armazenar
            Multiplos valores em diversas posicoes, porem
            somente um valor por posicao.
            
            Abaixo temos um exemplo com um vetor do tipo
            inteiro, chamado "meuVetor", nele iremos
            atribuir valores inteiros e logo em seguida
            iremos escrever os valores do vetor "meuVetor"
            na tela do usuario.
        */
        
        //                 VETOR SIMPLES
        /*Declaracao do vetor "meuVetor" do tipo inteiro
        com 4 posicoes*/
        int meuVetor[] = new int[4];
        
        //Colocando valores inteiros no vetor
        meuVetor[0] = 3; //A posicao 0 eh sempre a posicao inicial no java
        meuVetor[1] = 25;
        
        meuVetor[2] = 42;
        meuVetor[3] = 58;
        
        /*meuVetor[4] = 67; //*Se tentarmos colocar um QUINTO valor no vetor
        o java vai retornar um erro, pois o vetor suporta somente QUATRO
        posicoes dentro dele, cada uma com apenas um valor.* */
        
        //Escrevendo um valor do vetor na tela
        System.out.println("Posicao inicial vetor simples:"); //Apenas para facilitar a leitura
        System.out.println(meuVetor[0]);
        
        /*Escrevendo os valores na tela de forma
        automatizada*/
        for(int i=0;i<4;i++){
            System.out.println("VETOR SIMPLES:");
            System.out.println(meuVetor[i]);
        }
        
        /*LEMBRAR SEMPRE: Depois de cada iterador deve-se colocar ";"
          (ponto e virgula), porem ha um excessao. Depois do ultimo
          iterador nao se coloca ponto e virgula ";", no nosso caso
          eh a variavel de controle "i" em sua forma com operador
          unario "++", ficando "i++".
        */
        
        //                  VETOR COMPOSTO
        /*Declaracao do vetor "meuVetorComposto" do tipo inteiro
        com posicoes dinamicas e colocando os valores dentro
        do vetor*/
        int meuVetorComposto[] = {98,56,4,64,79,2,45,67};
        
        //Escrevendo um valor do vetor na tela
        System.out.println("Posicao inicial vetor composto:"); //Apenas para facilitar a leitura
        System.out.println(meuVetorComposto[0]);
        
        /*Escrevendo os valores na tela de forma
        automatizada*/
        for(int j=0;j<8;j++){
            /*A quantidade de posicoes existentes no vetor
            utilizado eh igual a 8, porem se removermos
            ou adicionarmos posicoes no vetor devemos
            mudar o limite da variavel de controle.*/
            System.out.println("VETOR COMPOSTO:");
            System.out.println(meuVetorComposto[j]);
        }
        
        /*Escrevendo os valores na tela de forma
        mais automatizada ainda. Neste caso ja
        nao precisamos mais informar o comprimento
        do vetor, pois o java calcula automaticamente.
        
        Como a expressao passada foi "j<duracao" nao
        precisamos subtrair um da variavel "duracao",
        pois o proprio operador "<" faz este papel.
        
        Exemplos:
            duracao << 8;
            8 eh menor que 8? Nao
            
            9 eh menor que 8? Nao
            7 eh menor que 8? Sim
        
        Por que?
            8 = (8-0);
            
            7 = (8-1);
            9 = (8+1);
        
        O unico caso em que iriamos precisar subtrair 1 unidade
        da variavel "duracao" seria se o operador fosse "<="
        (menor ou igual).
        */
        
        //Conta quantas posicoes o vetor possui
        int duracao = meuVetorComposto.length;
        
        for(int j=0;j<duracao;j++){
            /*A quantidade de posicoes existentes no vetor
            utilizado eh igual a 8, porem se removermos
            ou adicionarmos posicoes no vetor devemos
            mudar o limite da variavel de controle.*/
            System.out.println("VETOR COMPOSTO II:");
            System.out.println(meuVetorComposto[j]);
        }
        /*Escrevendo os valores na tela de forma
        automatizada e estilosa! :-)*/
        for(int k=0;k<8;k++){
            //Variavel de controle "k";
            System.out.println("Na pos. " +k+ " temos o valor "+meuVetorComposto[k]);
        }
    }
    
}
