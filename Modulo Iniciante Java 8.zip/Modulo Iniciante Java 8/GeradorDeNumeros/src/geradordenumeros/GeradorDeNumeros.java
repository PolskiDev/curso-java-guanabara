/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package geradordenumeros;

import java.util.Scanner;

/**
 * @author Gabriel Margarido
 */

/*
    Gera numeros inteiros ate o limite inserido
    na variavel "numero". Independente de qual
    numero inteiro seja inserido.
*/
public class GeradorDeNumeros {

    /**
     * @param args the command line arguments
     */
    public static void gerarNumeros(int indice) {
        int contador = 0;
        while (contador < indice) {
            contador = contador + 1;
            System.out.println("N. "+contador);
        }
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner entrada = new Scanner(System.in);
        
        System.out.print("Digite o limite (int): ");
        int numero = entrada.nextInt();
        gerarNumeros(numero);
    }
    
}
