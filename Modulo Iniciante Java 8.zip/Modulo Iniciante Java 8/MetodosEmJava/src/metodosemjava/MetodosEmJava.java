/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodosemjava;

/**
 *
 * @author Gabriel Margarido
 */

/*                      METODOS EM JAVA
    1a regra: Um metodo NAO pode ser declarado DENTRO de outro metodo,
    porem pode ser chamado dentro de outro.

    2a regra: O java nao possui uma palavra reservada que indique
    especificamente um metodo, como em outras linguagens: Lua,
    Ruby, C ou ate Python. (function, def, func OU method)
    entre outras palavras...

    3a regra: O tipo do metodo indica se havera algum tipo de retorno
    ou nao. A unica palavra reservada que indica que nao havera algum
    tipo de retorno ao fim da execucao do metodo eh "void".

    As palavras reservadas que indicam os tipos de variaveis,
    vetores e constantes tambem sao usadas para declarar o tipo
    de retorno dos metodos: [int, float, char, boolean, byte,
    short, long, double]
    
    4a regra: Metodos estaticos sao exclusivos para classes e nao
    para instancias. Sendo assim os metodos estaticos sao declarados
    e identificados pelo modificador "static".
    
    5a regra: Metodos declarados com o modificador "private" possuem
    nivel de acesso privado, ou seja podem ser chamados somente dentro
    da classe em qual foram declarados. Caso queira que o metodo seja
    acessivel de qualquer lugar ou qualquer codigo, ele deve ser declarado
    com o modificador "public".
    
    6a regra: O metodo de nome "main" eh exclusivo para uso do compilador
    java (JavaC) e deve ser usado exclusivamente para conter as instrucoes
    principais do seu programa. Quaisquer outros metodos devem ser
    declarados com qualquer outro nome que nao seja "main".
*/
public class MetodosEmJava {

    /**
     * @param args the command line arguments
     */
    
    //              METODOS AUXILIARES
    static int somar(int a, int b) {
        return a+b;
    }
    static int subtrair(int a, int b) {
        return a-b;
    }
    
    //              METODO PRINCIPAL        
    public static void main(String[] args) {
        // TODO code application logic here
        
        //Chama os metodos declarados acima;
        int d = somar(2,5);
        int h = subtrair(5,2);
        
        
        /*Chama os metodos declarados no arquivo "ClasseJava.java";
        
        ***LEMBRAR: Nomes de classes ou interfaces sempre comecam***
        com a primeira letra maiuscula*/
        int f = ClasseJava.somar(2,5);
        int z = ClasseJava.subtrair(5,2);
        
        //Imprime na tela os resultados locais
        System.out.println("A soma (local) eh: "+d);
        System.out.println("A subtracao (local) eh: "+h);
        
        //Pula a linha
        System.out.println("");
        
        //Imprime na tela os resultados de "ClasseJava.java";
        System.out.println("A soma (ClasseJava.java) eh: "+f);
        System.out.println("A subtracao (ClasseJava.java) eh: "+z);
        
        //Fim do programa
        //return 0;
    }
    
}
