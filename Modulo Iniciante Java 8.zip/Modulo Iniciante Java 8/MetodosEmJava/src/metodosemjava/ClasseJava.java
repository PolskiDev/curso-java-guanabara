/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodosemjava;

/**
 *
 * @author Gabriel Margarido
 */
public class ClasseJava {
    
    //Metodo de subtracao de inteiros
    public static int subtrair(int n, int x) {
        return n-x;
    }
    //Metodo de soma de inteiros
    public static int somar(int n, int x) {
        return n+x;
    }
}
