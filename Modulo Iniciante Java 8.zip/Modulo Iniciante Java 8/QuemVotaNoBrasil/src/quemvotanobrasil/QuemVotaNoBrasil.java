/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quemvotanobrasil;

import java.util.Scanner;

/**
 * @author Gabriel Margarido
 */
public class QuemVotaNoBrasil {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //VAR AREA
        Scanner getAge = new Scanner(System.in);
        
        // TODO code application logic here
        
        //Cria um WHILE loop para repeticao
        while(true){
            //Entrada de dados para "idade"
            System.out.println("Qual eh a sua idade? (Digite somente números inteiros)");
            int idade = getAge.nextInt();
            
            //Compara as idades
            if(idade<16) {
                System.out.println("Nao vota.");
            }else{
                //Se o primeiro caso for falso
                if(idade>=16 && idade<18){
                    System.out.println("Voto opcional.");
                }if(idade>=18 && idade<=70){
                    System.out.println("Voto obrigatorio.");
                }if(idade>70){
                    System.out.println("Voto opcional.");
                }
                /*Aqui nao ha necessidade de se colocar ELSE,
                pois todas as idades estao sendo colocadas do intervalo
                de 0 ate infinito.*/
            } 
        }
        
        
    }
    //Fim do programa
    //return 0;
        
}
