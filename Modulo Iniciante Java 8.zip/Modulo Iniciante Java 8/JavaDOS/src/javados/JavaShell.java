/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*                  IMPORTANT MODIFICATION
    You must import a module to execute succesfully the methods inside
    this class file. Copy the text below and paste it at the imports area.
    
    COPY AND PASTE THIS TEXT:
    import java.io.IOException;
*/
package javados; //CHANGE THE PACKAGE NAME TO YOUR PACKAGE NAME!!!
import java.io.IOException;

/**
 *
 * @author Gabriel Margarido
 */
public class JavaShell {
    static final Runtime FUNCRUNTIME = Runtime.getRuntime();
    static Process processRuntime;

        /**
         *
         * 
         * @param winCmd
         * @throws IOException
         */
    //                  MICROSOFT WINDOWS
    public static void winRuntime(String winCmd) throws IOException {
        //main instruction
        processRuntime = FUNCRUNTIME.exec("cmd /c "+winCmd);
    }
    
    //                  APPLE MAC OS X
    public static void appleRuntime(String appleCmd) throws IOException {
        //main instruction
        processRuntime = FUNCRUNTIME.exec(appleCmd);
    }
    
    //                  GNU/LINUX OPERATING SYSTEM
    public static void gnuRuntime(String gnuCmd) throws IOException {
        //main instruction
        processRuntime = FUNCRUNTIME.exec(gnuCmd);
    }
}
