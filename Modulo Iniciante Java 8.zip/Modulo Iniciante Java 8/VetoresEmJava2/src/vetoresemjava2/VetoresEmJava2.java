/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vetoresemjava2;

import java.util.Arrays;

/**
 *
 * @author Gabriel Margarido
 */
public class VetoresEmJava2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int vetorJ[] = {68,45,12,98,150,77,850,100};
        
        int vetorTamanho = vetorJ.length;
        for(int i=0;i<vetorTamanho;i++) {
            System.out.println(Arrays.sort(vetorJ));
        }
    }
    
}
