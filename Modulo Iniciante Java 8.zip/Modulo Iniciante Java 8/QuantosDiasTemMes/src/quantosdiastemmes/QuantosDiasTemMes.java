/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quantosdiastemmes;

import java.util.Scanner;

/**
 *
 * @author Gabriel Margarido
 */
public class QuantosDiasTemMes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String vetorMes[] = {"Janeiro","Fevereiro","Marco","Abril","Maio",
            "Junho", "Julho","Agosto","Setembro","Outubro","Novembro",
            "Dezembro"};
        
        //long vetorNumeroDoMes[] = {01,02,03,04,05,06,07,08,09,10,11,12};
        int vetorDias[] = {31,28,31,30,31,30,31, 31,30,31,30,31};
        int duracao = vetorMes.length;
        
        /*      DESAFIO - ANO BISSEXTO?
        
        System.out.println("Digite o ano:");
        Scanner entrada = new Scanner(System.in);
        int ano = entrada.nextInt();
        
        //LOGIC AREA - Ano bissexto?
        if (ano%4 != 0) {
            vetorDias[0] = 28;
        }else{
            vetorDias[1] = 29;
        }
        */
        
        for(int i=0; i<duracao; i++){
            System.out.println("O mes "+vetorMes[i]+" tem "
            +vetorDias[i]+" dias.");
        } 
        
    }
    
}
